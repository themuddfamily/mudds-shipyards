extends SceneTree
func _init():
	call_deferred("_run")
func _run():
	var ship = load("res://scenes/ships/bulwark_heavy_gunship.tscn").instantiate()
	root.add_child(ship)
	await process_frame
	for node in ship.find_children("*", "MeshInstance3D", true, false):
		if node.name != "FitoutRenderBatch02": continue
		print("BATCH ",ship.get_path_to(node)," RECORDS ",node.get_meta("ship_fitout_batch_authored_pieces",[]))
		for s in node.mesh.get_surface_count():
			var arrays = node.mesh.surface_get_arrays(s)
			var v = arrays[Mesh.ARRAY_VERTEX]
			var n = arrays[Mesh.ARRAY_NORMAL]
			var idx = arrays[Mesh.ARRAY_INDEX]
			var count = idx.size() if idx != null and not idx.is_empty() else v.size()
			for i in range(0,count,3):
				var ids = [idx[i],idx[i+1],idx[i+2]] if idx != null and not idx.is_empty() else [i,i+1,i+2]
				var cross = (v[ids[1]]-v[ids[0]]).cross(v[ids[2]]-v[ids[0]])
				var normal = n[ids[0]]+n[ids[1]]+n[ids[2]]
				if cross.dot(normal)>0.00000001:
					print("BAD surface=",s," offset=",i," ids=",ids," vertices=",[v[ids[0]],v[ids[1]],v[ids[2]]]," normals=",[n[ids[0]],n[ids[1]],n[ids[2]]]," dot=",cross.dot(normal))
	ship.free()
	quit()
