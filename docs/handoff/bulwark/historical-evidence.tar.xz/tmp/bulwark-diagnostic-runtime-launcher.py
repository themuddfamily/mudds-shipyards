#!/usr/bin/python3
"""Separate import, shared test and binding test commands; never chains engines."""
import ctypes, hashlib, json, os, pathlib, re, signal, subprocess, sys, time
WT = pathlib.Path('/tmp/mudds-bulwark-remote-aim-diagnostic')
MAIN = pathlib.Path('/root/mudds-shipyards')
HEAD = '3dfac88ca968d6f6e7fc065d558ea24fdf38bf24'
ENGINE = '/usr/local/bin/godot'
SCRIPT = 'res://tests/world/shared_ember_surface_activity_test.gd'
MARKER = 'SHARED_EMBER_SURFACE_ACTIVITY_TEST_OK'
ROUNDTRIP_MARKER = 'SHARED_EMBER_SURFACE_ROUNDTRIP_TEST_OK'
PASSENGER_SCRIPT = 'res://tests/network/halyard_network_passenger_route_test.gd'
PRIVATE_DISPLAY = pathlib.Path('/root/.cache/mudds-shipyards/roadmap-validation/checkpoint-linux-shared-surface-host-reentry-prepared/displays/passenger/private-display.py')
PRIVATE_DISPLAY_SHA256 = '84a1f81c04a61d719b4cdfc994bcec2c9d32ce972713b8dc0db9c64e9e93e273'

def identity(pid):
    try:
        parts = pathlib.Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
        return [pid, parts[19]], int(parts[1]), int(parts[2]), parts[0]
    except (OSError, ValueError):
        return None

def same_identity(pid, start):
    current = identity(pid)
    return current is not None and current[0][1] == start

def processes():
    result = []
    for d in pathlib.Path('/proc').iterdir():
        if d.name.isdecimal():
            item = identity(int(d.name))
            if item:
                result.append(item)
    return result

def census():
    result = []
    for ident, ppid, pgid, state in processes():
        try:
            d = pathlib.Path(f'/proc/{ident[0]}')
            exe = os.readlink(d / 'exe')
            cmd = (d / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
            cwd = os.readlink(d / 'cwd')
        except OSError:
            continue
        name = pathlib.Path(exe).name.lower()
        if 'godot' in name or (name.endswith('.exe') and 'mudds' in (cmd + cwd).lower()):
            result.append({'identity': ident, 'exe': exe, 'cwd': cwd, 'cmd': cmd})
    return result

def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args], env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})

def pin(root):
    names = git(root, 'ls-files', '-z', '--cached', '--others', '--exclude-standard').split(b'\0')
    files = {}
    for raw in names:
        if not raw: continue
        name = os.fsdecode(raw)
        if name.startswith('.godot/'): continue
        p = root / name
        if p.is_symlink(): files[name] = 'link:' + os.readlink(p)
        elif p.is_file(): files[name] = hashlib.sha256(p.read_bytes()).hexdigest()
        else: files[name] = 'absent'
    index = pathlib.Path(os.fsdecode(git(root, 'rev-parse', '--path-format=absolute', '--git-path', 'index').strip()))
    return {'head': git(root, 'rev-parse', 'HEAD').decode().strip(), 'index': hashlib.sha256(index.read_bytes()).hexdigest(), 'status': git(root, 'status', '--porcelain=v1').decode(), 'files': files}

def tree_hash(root):
    h = hashlib.sha256()
    for p in sorted(root.rglob('*')):
        if p.is_file():
            h.update(str(p.relative_to(root)).encode() + b'\0' + hashlib.sha256(p.read_bytes()).digest())
    return h.hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

# This helper is entered only inside the newly created network namespace.
if len(sys.argv) > 1 and sys.argv[1] == '--netexec':
    out = pathlib.Path(sys.argv[2])
    save(out / 'namespace-helper.json', {'identity': identity(os.getpid())[0], 'net_namespace': os.readlink('/proc/self/ns/net')})
    child = subprocess.Popen(['/usr/sbin/ip', 'link', 'set', 'lo', 'up'])
    save(out / 'loopback-child.json', {'identity': identity(child.pid)[0]})
    if child.wait() != 0: sys.exit(73)
    save(out / 'engine-exec.json', {'identity': identity(os.getpid())[0], 'command': sys.argv[3:]})
    os.execv(sys.argv[3], sys.argv[3:])

if len(sys.argv) != 2 or sys.argv[1] not in ('import', 'test', 'binding', 'roundtrip', 'host', 'api', 'passenger', 'crew', 'presentation', 'coordinator', 'crew_parse', 'intent', 'aurora_parse', 'roundtrip_profile', 'surface_parse', 'roundtrip_ascent_profile', 'roundtrip_walk_profile', 'audio', 'environment', 'sun', 'arrow_entry', 'return_status', 'home_approach', 'home_approach_baseline', 'aurora_arrival', 'rime_arrival', 'walk_strength', 'shared_cruise', 'helm', 'body', 'gunner'):
    sys.exit('usage: python3 /tmp/shared-surface-focused-launcher.py import|test|binding|roundtrip|host|api|passenger|crew')
mode = sys.argv[1]
if mode == 'gunner':
    assert hashlib.sha256((WT / 'tests/network/bulwark_network_gunner_route_test.gd').read_bytes()).hexdigest() == 'd3b5ce3a93726d79447cc7bda95293440559e31c1c8d4cb94fbb10306f99e20a', 'frozen gunner fixture bytes changed'
peer_roles = ('host', 'client', 'client_b', 'observer') if mode == 'shared_cruise' else ('host', 'client')
assert os.environ.get('HOME') == '/root', 'HOME must remain /root'
assert not census(), 'Mudds engine lane is occupied'
before = {'candidate': pin(WT), 'main': pin(MAIN)}
assert before['candidate']['head'] == HEAD and not before['candidate']['status'], 'frozen candidate moved or dirty'
patch = git(WT, 'diff', '--binary', '31d70662c1927ec06ba9f3db8a33fa65d547f243', 'HEAD')
assert hashlib.sha256(patch).hexdigest() == '7d30e123c56ba27c02645f27b9414a243662c193632a9eee5bdad24f7a9c434a'
if mode == 'import': assert not (WT / '.godot').exists(), 'cold import must start without cache'
else: assert (WT / '.godot').is_dir(), 'test requires reviewed cold import'
out = pathlib.Path('/tmp') / ('shared-surface-' + mode + '-' + str(time.time_ns()))
out.mkdir(mode=0o700)
save(out / 'source-before.json', before)
cache_before = tree_hash(WT / '.godot') if mode != 'import' else None
if mode != 'import': assert cache_before == '87adbdaebdc28576d879f80ace9d34df6218f8d0f85f32269fe4e5c15ad3f516', 'cold-import cache baseline changed'
env = {k:v for k,v in os.environ.items() if not k.upper().startswith(('DBUS', 'DISPLAY', 'WAYLAND', 'TEST_MATRIX', 'PACKAGE_PROBE')) and k not in ('XAUTHORITY', 'GDK_BACKEND', 'QT_QPA_PLATFORM')}
for key in ('XDG_CONFIG_HOME','XDG_DATA_HOME','XDG_CACHE_HOME','XDG_RUNTIME_DIR'):
    p = out / key.lower()
    p.mkdir(mode=0o700)
    env[key] = str(p)
env['GIT_OPTIONAL_LOCKS'] = '0'
# Mode is selected explicitly; inherited success flags cannot change other lanes.
env.pop('KETH_SHARED_SURFACE_SUCCESS', None)
env.pop('KETH_SHARED_SURFACE_ASCENT_PROFILE', None)
env.pop('KETH_SHARED_SURFACE_PROFILE', None)
if mode == 'roundtrip_walk_profile': env['KETH_SHARED_SURFACE_PROFILE'] = 'return_walk'
env.pop('MUDDS_TRACE_EMBER_HATCH_REFUSAL', None)
env.pop('MUDDS_TRACE_EMBER_PASSENGER_HANDOFF', None)
if mode in ('crew', 'shared_cruise'): env['MUDDS_TRACE_EMBER_PASSENGER_HANDOFF'] = '1'
if mode == 'crew': env['MUDDS_TRACE_EMBER_HATCH_REFUSAL'] = '1'
if mode in ('roundtrip', 'roundtrip_profile', 'roundtrip_ascent_profile', 'roundtrip_walk_profile'): env['KETH_SHARED_SURFACE_SUCCESS'] = '1'
if mode == 'roundtrip_ascent_profile': env['KETH_SHARED_SURFACE_ASCENT_PROFILE'] = '1'
if mode in ('gunner', 'passenger', 'crew', 'aurora_arrival', 'rime_arrival', 'shared_cruise', 'helm'):
    # Reuse the reviewed authenticated display owner; retarget only its cwd.
    display_bytes = PRIVATE_DISPLAY.read_bytes()
    assert hashlib.sha256(display_bytes).hexdigest() == PRIVATE_DISPLAY_SHA256
    display_text = display_bytes.decode()
    old_display_wt = "WT = Path('/root/.cache/mudds-shipyards/roadmap-work/checkpoint-linux-shared-ember-cancellation-prepared')"
    assert display_text.count(old_display_wt) == 1
    display_copy = out / 'private-display.py'
    display_copy.write_text(display_text.replace(old_display_wt, 'WT = Path(' + repr(str(WT)) + ')'))
    shim_dir = out / 'bin'
    shim_dir.mkdir(mode=0o700)
    shim = shim_dir / 'xvfb-run'
    shim.write_text('''#!/usr/bin/python3
import os, pathlib, sys
args = sys.argv[1:]
assert args[0] == '-a' and args[1].startswith('--server-args=')
command = args[2:]
assert command[:2] == ['/bin/sh', '-c']
role = pathlib.Path(command[3]).name
assert role in __ALLOWED_PEER_ROLES__
out = pathlib.Path(os.environ['SHARED_SURFACE_DISPLAY_ROOT'])
fd = os.open(out / ('peer-' + role + '.log'), os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
os.dup2(fd, 1); os.dup2(fd, 2); os.close(fd)
os.execv(sys.executable, [sys.executable, str(out / 'private-display.py'), role, str(out / (role + '-display.json')), args[1], '--', *command])
'''.replace('__ALLOWED_PEER_ROLES__', repr(peer_roles)))
    if mode == 'helm':
        shim.write_text('''#!/usr/bin/python3
import os, pathlib, subprocess, sys
args = sys.argv[1:]
assert args[0] == '-a' and args[1].startswith('--server-args=')
command = args[2:]
assert command[:2] == ['/bin/sh', '-c']
prefix = pathlib.Path(command[3])
assert prefix.name == 'peer'
out = pathlib.Path(os.environ['SHARED_SURFACE_DISPLAY_ROOT'])
fd = os.open(out / 'peer-peer.log', os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
os.dup2(fd, 1); os.dup2(fd, 2); os.close(fd)
child = subprocess.Popen([sys.executable, str(out / 'private-display.py'), 'client', str(out / 'client-display.json'), args[1], '--', *command])
code = child.wait()
# Preserve the fixture's actual waited actor records before the outer private
# profile owner removes them; these are copies, never replacement exit records.
for suffix in ('pid', 'exit', 'log'):
    source = prefix.with_name(prefix.name + '.' + suffix)
    assert source.is_file() and not source.is_symlink()
    fd = os.open(out / ('helm-peer.' + suffix), os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(source.read_bytes())
sys.exit(code)
''')
    shim.chmod(0o700)
    env['PATH'] = str(shim_dir) + os.pathsep + env.get('PATH', os.defpath)
    env['SHARED_SURFACE_DISPLAY_ROOT'] = str(out)
command = [ENGINE, '--headless', '--audio-driver', 'Dummy', '--path', str(WT)]
if mode == 'helm': command = [ENGINE, '--display-driver', 'x11', '--rendering-driver', 'dummy', '--disable-render-loop', '--audio-driver', 'Dummy', '--path', str(WT)]
if mode == 'roundtrip_profile': command += ['--debug', '--profiling', '--ignore-error-breaks']
if mode in ('roundtrip_ascent_profile', 'roundtrip_walk_profile'): command += ['--debug', '--ignore-error-breaks']
test_script = {'gunner': 'res://tests/network/bulwark_network_gunner_route_test.gd', 'body': 'res://tests/network_remote_body_simulation_test.gd', 'helm': 'res://tests/network_remote_pilot_helm_test.gd', 'walk_strength': 'res://tests/player_step_up_assist_test.gd', 'home_approach_baseline': 'res://tests/game_flow_planetary_return_approach_test.gd', 'home_approach': 'res://tests/game_flow_planetary_return_approach_test.gd', 'audio': 'res://tests/audio/ember_surface_loop_audio_production_test.gd', 'environment': 'res://tests/ember_airless_environment_production_test.gd', 'sun': 'res://tests/ember_airless_sun_streaming_bootstrap_test.gd', 'arrow_entry': 'res://tests/arrow_entry_presentation_production_caller_test.gd', 'return_status': 'res://tests/ember_surface_return_status_binding_test.gd', 'intent': 'res://tests/network/network_remote_body_intent_source_test.gd', 'aurora_parse': 'res://tests/network/halyard_network_shared_planetary_cruise_test.gd', 'coordinator': 'res://tests/world_streaming_coordinator_test.gd', 'presentation': 'res://tests/game_flow_ember_surface_presentation_integration_test.gd', 'binding': 'res://tests/ember_surface_loop_production_binding_test.gd', 'host': 'res://tests/ember_surface_loop_host_test.gd', 'api': 'res://tests/world/ember_surface_loop_relay_survey_api_test.gd', 'passenger': PASSENGER_SCRIPT, 'crew': PASSENGER_SCRIPT, 'crew_parse': PASSENGER_SCRIPT}.get(mode, SCRIPT)
if mode in ('aurora_arrival', 'rime_arrival', 'shared_cruise'): test_script = 'res://tests/network/halyard_network_shared_planetary_cruise_test.gd'
command += ['--editor', '--import'] if mode == 'import' else ['--script', test_script]
if mode in ('crew_parse', 'aurora_parse', 'surface_parse'): command += ['--check-only']
if mode == 'crew': command += ['--', '--ember-surface']
if mode in ('aurora_arrival', 'rime_arrival'): command += ['--', '--aurora-shared-arrival' if mode == 'aurora_arrival' else '--rime-shared-arrival']
cap = {'gunner': 300, 'body': 300, 'home_approach_baseline': 300, 'home_approach': 300, 'audio': 300, 'environment': 300, 'sun': 300, 'arrow_entry': 300, 'return_status': 300, 'roundtrip_walk_profile': 2400, 'roundtrip_ascent_profile': 2400, 'surface_parse': 60, 'roundtrip_profile': 2400, 'intent': 60, 'aurora_parse': 60, 'coordinator': 60, 'presentation': 300, 'import': 300, 'binding': 900, 'test': 360, 'roundtrip': 2400, 'host': 300, 'api': 30, 'passenger': 120, 'crew': 2400, 'crew_parse': 60, 'aurora_arrival': 2400, 'rime_arrival': 2400, 'walk_strength': 300, 'shared_cruise': 300, 'helm': 300}[mode]
if mode == 'helm':
    command = [sys.executable, str(display_copy), 'orchestrator', str(out / 'orchestrator-display.json'), '--server-args=-screen 0 1280x720x24 -nolisten unix -nolisten tcp', '--', *command]
save(out / 'command.json', {'command': command, 'cap_seconds': cap, 'network': 'private unshare net; loopback up; no fallback', 'HOME': env['HOME']})
# Become subreaper so detached descendants remain owned and can be reaped.
assert ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0
owned = set()
child = None
aborted = False

def capture_owned():
    # Private display owners create separate process groups. Capture their
    # descendants while parent identities are current, rather than losing them.
    current = processes()
    while True:
        parents = {pid for pid, start in owned if any(i[0] == pid and i[1] == start for i, _, _, _ in current)}
        added = {tuple(i) for i, ppid, pgid, _ in current if pgid == child.pid or ppid == os.getpid() or ppid in parents} - owned
        if not added: break
        owned.update(added)

def abort(signum, frame):
    global aborted
    aborted = True
signal.signal(signal.SIGTERM, abort)
signal.signal(signal.SIGINT, abort)
print('ARTIFACTS=' + str(out), flush=True)
try:
    with (out / 'engine.log').open('wb') as log:
        child = subprocess.Popen(['/usr/bin/unshare', '--net', '--', '/usr/bin/python3', __file__, '--netexec', str(out), *command], env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        first = identity(child.pid)
        if first: owned.add(tuple(first[0]))
        save(out / 'supervised-child.json', {'identity': first[0] if first else None, 'pgid': child.pid})
        print('SUPERVISED_PID=' + str(child.pid), flush=True)
        deadline = time.monotonic() + cap
        while child.poll() is None and not aborted and time.monotonic() < deadline:
            capture_owned()
            time.sleep(0.1)
        if child.poll() is None:
            aborted = True
            os.killpg(child.pid, signal.SIGTERM)
            try: child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait(timeout=10)
        code = child.wait()
finally:
    if child:
        capture_owned()
        for name in ('namespace-helper.json','loopback-child.json','engine-exec.json'):
            p = out / name
            if p.exists(): owned.add(tuple(json.loads(p.read_text())['identity']))
        save(out / 'owned-identities.json', [list(p) for p in sorted(owned)])
        end = time.monotonic() + 10
        if child.returncode == 0 and not aborted:
            # Successful peers can exit before their display owners finish
            # writing/reaping. Share the original cleanup budget, retain five
            # seconds for terminating survivors, and never extend the run cap.
            natural_end = min(deadline, end - 5)
            while not aborted and time.monotonic() < natural_end:
                capture_owned()
                try:
                    while os.waitpid(-1, os.WNOHANG)[0]: pass
                except ChildProcessError: pass
                if not any(same_identity(pid, start) for pid, start in owned): break
                time.sleep(0.1)
        for pid, start in owned:
            current = identity(pid)
            if current and current[0][1] == start and current[3] != 'Z':
                try: os.kill(pid, signal.SIGTERM)
                except ProcessLookupError: pass
        while time.monotonic() < end:
            try:
                while os.waitpid(-1, os.WNOHANG)[0]: pass
            except ChildProcessError: pass
            if not any(same_identity(pid, start) for pid,start in owned): break
            time.sleep(0.1)
        for pid, start in owned:
            current = identity(pid)
            if current and current[0][1] == start:
                try: os.kill(pid, signal.SIGKILL)
                except ProcessLookupError: pass
        try:
            while os.waitpid(-1, os.WNOHANG)[0]: pass
        except ChildProcessError: pass
# Import-created UID sidecars are source artifacts: record and remove only new
# untracked .gd.uid sidecars for tracked .gd files, never pre-existing files.
after_raw = {'candidate': pin(WT), 'main': pin(MAIN)}
save(out / 'source-after-raw.json', after_raw)
removed = []
if mode == 'import':
    for name in sorted(set(after_raw['candidate']['files']) - set(before['candidate']['files'])):
        if name.endswith('.gd.uid') and name[:-4] in before['candidate']['files']:
            removed.append({'path': name, 'sha256': after_raw['candidate']['files'][name]})
            (WT / name).unlink()
save(out / 'generated-sidecars-cleaned.json', removed)
after = {'candidate': pin(WT), 'main': pin(MAIN)}
save(out / 'source-after.json', after)
remaining = [list(p) for p in sorted(owned) if same_identity(p[0], p[1])]
cache = tree_hash(WT / '.godot') if (WT / '.godot').is_dir() else None
logtext = (out / 'engine.log').read_text(errors='replace')
success_lines = [line for line in logtext.splitlines() if re.fullmatch(r'EMBER_SURFACE_LOOP_PRODUCTION_BINDING_TEST_OK assertions=83 diagnostics=0', line)] if mode == 'binding' else [line for line in logtext.splitlines() if line == {'walk_strength': 'PLAYER_STEP_UP_ASSIST_TEST_OK', 'intent': 'OK: network remote body intent source (72 assertions)', 'coordinator': 'WORLD_STREAMING_COORDINATOR_TEST_OK', 'host': 'EMBER_SURFACE_LOOP_HOST_TEST_OK', 'api': 'EMBER_SURFACE_LOOP_RELAY_SURVEY_API_TEST_OK'}.get(mode, MARKER)]
if mode == 'presentation': success_lines = re.findall(r'^GAME_FLOW_EMBER_SURFACE_PRESENTATION_INTEGRATION_TEST_OK \(([1-9][0-9]*) assertions\)$', logtext, re.M)
focused_patterns = {
    'body': r'^NETWORK_REMOTE_BODY_SIMULATION_TEST_OK: ([1-9][0-9]*) assertions$',
    'helm': r'^NETWORK_REMOTE_PILOT_HELM_TEST_OK: ([1-9][0-9]*) assertions$',
    'home_approach_baseline': r'^GAME_FLOW_PLANETARY_RETURN_APPROACH_TEST_OK: ([1-9][0-9]*) assertions$',
    'home_approach': r'^GAME_FLOW_PLANETARY_RETURN_APPROACH_TEST_OK: ([1-9][0-9]*) assertions$',
    'audio': r'^EMBER_SURFACE_LOOP_AUDIO_PRODUCTION_TEST: ([1-9][0-9]*) assertions$',
    'environment': r'^EMBER_AIRLESS_ENVIRONMENT_PRODUCTION_TEST_OK: 16 assertions$',
    'sun': r'^PASS: Ember streamed airless sun production \(([1-9][0-9]*) assertions\)$',
    'arrow_entry': r'^ARROW_ENTRY_PRESENTATION_PRODUCTION_CALLER_TEST_OK: 14 assertions$',
    'return_status': r'^EMBER_SURFACE_RETURN_STATUS_BINDING_TEST_OK \(([1-9][0-9]*) assertions\)$',
}
if mode in focused_patterns: success_lines = re.findall(focused_patterns[mode], logtext, re.M)
error_lines = [line for line in logtext.splitlines() if any(token in line for token in ('SCRIPT ERROR', 'Parse Error', 'ERROR:'))]
peer_failures = []
if mode in ('passenger', 'crew', 'aurora_arrival', 'rime_arrival', 'shared_cruise'):
    routes = re.findall(r'^HALYARD_NETWORK_PASSENGER_ROUTE: ([1-9][0-9]*) checks, 0 failures$', logtext, re.M)
    success_lines = routes
    terrain = re.findall(r'^HALYARD_NETWORK_EMBER_PASSENGER_TERRAIN_OK checks=([1-9][0-9]*)$', logtext, re.M)
    if (mode in ('crew', 'aurora_arrival', 'rime_arrival') and terrain != routes) or (mode in ('passenger', 'shared_cruise') and terrain): peer_failures.append('terrain marker/mode mismatch')
    if mode in ('aurora_arrival', 'rime_arrival'):
        arrival_marker = 'HALYARD_NETWORK_SHARED_AURORA_ARRIVAL_OK' if mode == 'aurora_arrival' else 'HALYARD_NETWORK_SHARED_RIME_ARRIVAL_OK'
        if sum(line == arrival_marker for line in logtext.splitlines()) != 1: peer_failures.append('world-specific shared arrival marker absent/duplicate')
    if mode == 'passenger':
        ordinary = re.findall(r'^HALYARD_NETWORK_PASSENGER_ROUTE_TEST_OK checks=([1-9][0-9]*)$', logtext, re.M)
        if ordinary != routes: peer_failures.append('ordinary passenger filename marker absent/duplicate/count mismatch')
    if mode == 'shared_cruise':
        if sum(line == 'HALYARD_NETWORK_SHARED_PLANETARY_CRUISE_TEST_OK' for line in logtext.splitlines()) != 1: peer_failures.append('default shared cruise marker absent/duplicate')
    engine_pid = json.loads((out / 'engine-exec.json').read_text())['identity'][0]
    peer_dir = pathlib.Path('/tmp') / ('mudds-passenger-peers-' + str(engine_pid))
    if re.findall(r'^PASSENGER_PEER_ARTIFACTS: (.+)$', logtext, re.M) != [str(peer_dir)]: peer_failures.append('actual peer directory marker absent/mismatch')
    if hashlib.sha256(PRIVATE_DISPLAY.read_bytes()).hexdigest() != PRIVATE_DISPLAY_SHA256: peer_failures.append('private display input changed')
    if mode == 'shared_cruise':
        if sorted(p.name[:-5] for p in peer_dir.glob('*.done')) != sorted(peer_roles): peer_failures.append('default shared cruise actual peer roster mismatch')
    for role in peer_roles:
        try:
            peer_log = (out / ('peer-' + role + '.log')).read_text(errors='replace')
            error_lines += [role + ': ' + line for line in peer_log.splitlines() if any(token in line for token in ('SCRIPT ERROR', 'Parse Error', 'ERROR:'))]
            if len(re.findall(r'^HALYARD_NETWORK_PASSENGER_' + role.upper() + r': ([1-9][0-9]*) checks, 0 failures$', peer_log, re.M)) != 1: peer_failures.append(role + ' final positive marker absent/duplicate')
            done = json.loads((peer_dir / (role + '.done')).read_text())
            if type(done.get('checks')) is not int or done['checks'] <= 0 or done.get('failures') != []: peer_failures.append(role + ' actual done failed')
            if (peer_dir / (role + '.exit')).read_text().strip() != '0': peer_failures.append(role + ' actual owning exit nonzero')
            pid = int((peer_dir / (role + '.pid')).read_text())
            if not any(p == pid for p, _ in owned): peer_failures.append(role + ' actual Godot identity not captured')
            record = json.loads((out / (role + '-display.json')).read_text())
            if not (record['preflight'] == 'PASS' and record['home_unchanged'] and record['direct_actor_exit'] == 0 and record['direct_actor_reaped'] and record['direct_actor_absent'] and record['wrapper_exit'] == 0 and record['wrapper_reaped'] and record['runtime_removed'] and record['xvfb_absent'] and not record['interrupted']): peer_failures.append(role + ' private display closure failed')
        except (OSError, ValueError, KeyError) as error:
            peer_failures.append(role + ': ' + str(error))
if mode == 'gunner':
    # The unchanged fixture reports this positive summary; it has no TEST_OK marker.
    success_lines = re.findall(r'^BULWARK_NETWORK_GUNNER_ROUTE: ([1-9][0-9]*) checks, 0 failures$', logtext, re.M)
    engine_pid = json.loads((out / 'engine-exec.json').read_text())['identity'][0]
    peer_dir = pathlib.Path('/tmp') / ('mudds-gunner-peers-' + str(engine_pid))
    if re.findall(r'^GUNNER_PEER_ARTIFACTS: (.+)$', logtext, re.M) != [str(peer_dir)]: peer_failures.append('actual peer directory marker absent/mismatch')
    if hashlib.sha256(PRIVATE_DISPLAY.read_bytes()).hexdigest() != PRIVATE_DISPLAY_SHA256: peer_failures.append('private display input changed')
    if mode == 'gunner':
        if sorted(p.name[:-5] for p in peer_dir.glob('*.done')) != sorted(peer_roles): peer_failures.append('gunner actual host/client roster mismatch')
    for role in peer_roles:
        try:
            peer_log = (out / ('peer-' + role + '.log')).read_text(errors='replace')
            error_lines += [role + ': ' + line for line in peer_log.splitlines() if any(token in line for token in ('SCRIPT ERROR', 'Parse Error', 'ERROR:'))]
            if len(re.findall(r'^BULWARK_NETWORK_GUNNER_' + role.upper() + r': ([1-9][0-9]*) checks, 0 failures$', peer_log, re.M)) != 1: peer_failures.append(role + ' final positive marker absent/duplicate')
            done = json.loads((peer_dir / (role + '.done')).read_text())
            if type(done.get('checks')) is not int or done['checks'] <= 0 or done.get('failures') != []: peer_failures.append(role + ' actual done failed')
            if (peer_dir / (role + '.exit')).read_text().strip() != '0': peer_failures.append(role + ' actual owning exit nonzero')
            pid = int((peer_dir / (role + '.pid')).read_text())
            if not any(p == pid for p, _ in owned): peer_failures.append(role + ' actual Godot identity not captured')
            record = json.loads((out / (role + '-display.json')).read_text())
            if not (record['preflight'] == 'PASS' and record['home_unchanged'] and record['direct_actor_exit'] == 0 and record['direct_actor_reaped'] and record['direct_actor_absent'] and record['wrapper_exit'] == 0 and record['wrapper_reaped'] and record['runtime_removed'] and record['xvfb_absent'] and not record['interrupted']): peer_failures.append(role + ' private display closure failed')
        except (OSError, ValueError, KeyError) as error:
            peer_failures.append(role + ': ' + str(error))
if mode == 'helm':
    if hashlib.sha256(PRIVATE_DISPLAY.read_bytes()).hexdigest() != PRIVATE_DISPLAY_SHA256: peer_failures.append('private display input changed')
    for role in ('orchestrator', 'client'):
        try:
            record = json.loads((out / (role + '-display.json')).read_text())
            if not (record['preflight'] == 'PASS' and record['home_unchanged'] and record['direct_actor_exit'] == 0 and record['direct_actor_reaped'] and record['direct_actor_absent'] and record['wrapper_exit'] == 0 and record['wrapper_reaped'] and record['runtime_removed'] and record['xvfb_absent'] and not record['interrupted']): peer_failures.append(role + ' helm private display closure failed')
            if (record['direct_actor_pid'], record['direct_actor_start']) not in owned: peer_failures.append(role + ' helm direct actor creation identity not captured')
        except (OSError, ValueError, KeyError) as error:
            peer_failures.append(role + ': ' + str(error))
    try:
        for name in ('peer-peer.log', 'helm-peer.log'):
            peer_text = (out / name).read_text(errors='replace')
            error_lines += [name + ': ' + line for line in peer_text.splitlines() if any(token in line for token in ('SCRIPT ERROR', 'Parse Error', 'ERROR:'))]
        pid = int((out / 'helm-peer.pid').read_text().strip())
        if pid <= 0 or not any(p == pid for p, _ in owned): peer_failures.append('actual helm Godot peer identity not captured')
        if (out / 'helm-peer.exit').read_text().strip() != '0': peer_failures.append('actual waited helm Godot peer exit nonzero')
        if re.findall(r'^HELM_GODOT_PEER_EXIT: pid=([1-9][0-9]*) exit=0$', logtext, re.M) != [str(pid)]: peer_failures.append('fixture actual successful helm peer exit marker absent/duplicate/mismatch')
    except (OSError, ValueError) as error:
        peer_failures.append('helm peer: ' + str(error))
summary = {'mode': mode, 'exit': code, 'aborted_or_timeout': aborted, 'owned_identities': [list(p) for p in sorted(owned)], 'remaining_identities': remaining, 'live_engine_census': census(), 'source_index_unchanged': after == before, 'cache_sha256': cache, 'cache_unchanged_during_test': cache == cache_before if mode != 'import' else None, 'success_marker_count': len(success_lines) if mode != 'import' else None, 'engine_error_count': len(error_lines)}
summary['peer_failures'] = peer_failures
summary['roundtrip_marker_count'] = sum(line == ROUNDTRIP_MARKER for line in logtext.splitlines())
save(out / 'result.json', summary)
print(json.dumps(summary), flush=True)
assert code == 0 and not aborted and not remaining and not summary['live_engine_census'] and after == before, 'operation failed or closure/source guard failed'
assert not error_lines, 'engine/import/peer error guard failed'
assert not peer_failures, 'passenger/crew marker, actual exit, or private display guard failed'
if mode != 'import': assert cache == cache_before, 'test cache guard failed'
if mode not in ('import', 'crew_parse', 'aurora_parse', 'surface_parse'): assert summary['success_marker_count'] == 1, 'test marker guard failed'
if mode in ('crew_parse', 'aurora_parse', 'surface_parse'): assert not success_lines and 'PASSENGER_PEER_ARTIFACTS:' not in logtext, 'parse-only lane unexpectedly executed route'
if mode in ('roundtrip', 'roundtrip_profile', 'roundtrip_ascent_profile', 'roundtrip_walk_profile'): assert summary['roundtrip_marker_count'] == 1, 'physical roundtrip marker absent or duplicate'
elif mode == 'test': assert summary['roundtrip_marker_count'] == 0, 'cancellation lane unexpectedly ran success mode'

if mode == 'home_approach': assert sum(line == 'RETURN_SHELL_ORIGIN_TRANSLATION_OK: committed local-home rebase preserves the exact shell and rejects forgery/replay before berth admission' for line in logtext.splitlines()) == 1, 'actual post-shell origin translation marker absent/duplicate'

if mode == 'home_approach': assert sum(line == 'HOME_RETURN_STREAMED_RELAY_CLEANUP_OK: strict home contract retires its composition without detaching the streamed-out relay twice' for line in logtext.splitlines()) == 1, 'actual streamed-relay cleanup marker absent/duplicate'
