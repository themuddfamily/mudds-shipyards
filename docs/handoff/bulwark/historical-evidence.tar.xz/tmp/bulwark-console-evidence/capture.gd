extends SceneTree
const Hauler := preload("res://scripts/ships/bulwark_heavy_gunship.gd")
func _init() -> void:
	call_deferred("_run")
func _run() -> void:
	root.size = Vector2i(1600, 900)
	root.content_scale_size = Vector2i.ZERO
	var stage := Node3D.new()
	root.add_child(stage)
	var craft := Hauler.new()
	stage.add_child(craft)
	await process_frame
	await physics_frame
	craft.set_canopy_open(true, 0.0)
	craft.set_process(false)
	craft.set_physics_process(false)
	var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color("081018")
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color.WHITE
	environment.ambient_light_energy = 0.7
	var world := WorldEnvironment.new()
	world.environment = environment
	stage.add_child(world)
	var fill := OmniLight3D.new()
	fill.position = Vector3(0, 5.0, -0.55)
	fill.light_energy = 1.2
	fill.omni_range = 8.0
	stage.add_child(fill)
	var camera := Camera3D.new()
	camera.fov = 48.0
	camera.near = 0.03
	camera.position = Vector3(0.0, 5.20, -0.56)
	stage.add_child(camera)
	camera.look_at(Vector3(0, 2.0, -0.55))
	camera.current = true
	for i in 12:
		await process_frame
	await RenderingServer.frame_post_draw
	var output := "/tmp/bulwark-console-evidence/" + OS.get_environment("BULWARK_CAPTURE_LABEL") + ".png"
	var image := root.get_texture().get_image()
	assert(image.get_size() == Vector2i(1600, 900))
	assert(image.save_png(output) == OK)
	print("BULWARK_CONSOLE_CAPTURE_OK: ", output, " adapter=", RenderingServer.get_video_adapter_name())
	craft.queue_free()
	await process_frame
	quit()
