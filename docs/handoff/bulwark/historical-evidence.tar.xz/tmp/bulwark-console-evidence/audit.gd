extends "res://tools/coplanar_seam_audit.gd"
const Hauler := preload("res://scripts/ships/bulwark_heavy_gunship.gd")
func _run_cli() -> void:
	var craft := Hauler.new()
	root.add_child(craft)
	await process_frame
	await physics_frame
	_collect_viewpoints(craft)
	_collect_renderers(craft, null)
	_index_faces()
	_find_pairs()
	_resolve_pairs()
	for finding in _findings:
		var record := JSON.stringify(finding)
		if "CockpitFloor" in record or "SideConsole" in record:
			print(record)
	craft.queue_free()
	await process_frame
	quit()
