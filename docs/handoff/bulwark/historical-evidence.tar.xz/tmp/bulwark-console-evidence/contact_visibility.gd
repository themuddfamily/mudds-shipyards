extends SceneTree
const Ship := preload("res://scripts/ships/bulwark_heavy_gunship.gd")
func _initialize() -> void:
	var craft := Ship.new()
	root.add_child(craft)
	await process_frame
	var cockpit := craft.get_node("BulwarkHeavyGunshipVisual/CockpitInterior") as Node3D
	var floor := cockpit.get_node("CockpitFloor") as MeshInstance3D
	var floor_top := (floor.transform * floor.get_aabb()).end.y
	var covered := 0
	var samples := 0
	for side in ["Port", "Starboard"]:
		var console := cockpit.get_node(side + "SideConsole") as MeshInstance3D
		var faces := console.mesh.get_faces()
		var bottom_triangles := 0
		for i in range(0, faces.size(), 3):
			var a := console.transform * faces[i]
			var b := console.transform * faces[i+1]
			var c := console.transform * faces[i+2]
			if not (is_equal_approx(a.y, floor_top) and is_equal_approx(b.y, floor_top) and is_equal_approx(c.y, floor_top)):
				continue
			bottom_triangles += 1
			assert((c-a).cross(b-a).normalized().dot(Vector3.DOWN) > 0.99)
			var target := (a+b+c)/3.0
			for camera in [Vector3(0,3.1,0.4), Vector3(0,2.12,-1.4), Vector3(0,5.2,-0.56)]:
				samples += 1
				var direction: Vector3 = camera.direction_to(target)
				var nearest := INF
				for t in range(0, faces.size(), 3):
					var hit: Variant = Geometry3D.ray_intersects_triangle(camera,direction,
						console.transform*faces[t],console.transform*faces[t+1],console.transform*faces[t+2])
					if hit != null:
						nearest = minf(nearest,camera.distance_to(hit))
				if nearest < camera.distance_to(target) - 0.0001:
					covered += 1
		print(side, " bottom_triangles=",bottom_triangles," bottom_normal=DOWN floor_top=",floor_top)
	print("BULWARK_CONTACT_VISIBILITY: ",covered,"/",samples," console-bottom samples occluded by console's own opaque crown/side")
	assert(samples == 24 and covered == samples)
	craft.queue_free()
	await process_frame
	quit()
